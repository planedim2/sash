# GM[Philanthrope]Visions — GitHub Pages Test

This is the first small test version of the website.

Files:
- index.html — main webpage
- style.css — website styling

GitHub Pages:
1. Upload both files to the repository.
2. Make sure `index.html` is in the root of the publishing source.
3. Go to Settings → Pages.
4. Under Build and deployment, choose `Deploy from a branch`.
5. Select `main` and `/ (root)`.
6. Click Save.
7. GitHub will provide the live site URL.

GitHub Pages can host static HTML/CSS/JavaScript files.
